const $ = id => document.getElementById(id);
const cfg = window.SAONA_CONFIG || {};
const configured = cfg.supabaseUrl?.startsWith("https://") &&
  cfg.supabaseAnonKey && !cfg.supabaseAnonKey.startsWith("PASTE_") &&
  cfg.adminUserId && !cfg.adminUserId.startsWith("PASTE_");
const supabase = configured && window.supabase ? window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey) : null;
let stories = [], activeStoryId = null, currentUser = null;

function esc(v) { return String(v ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function imageUrl(v) { try { const u = new URL(v); return ["https:","http:"].includes(u.protocol) ? u.href : ""; } catch { return ""; } }
function status(id, msg) { $(id).textContent = msg; }
function show(el, yes=true) { $(el).classList.toggle("hidden", !yes); }
function setupState(user) {
  currentUser = user;
  const isAdmin = !!user && user.id === cfg.adminUserId;
  show("adminToggle", isAdmin);
  show("adminStatus", isAdmin);
  if (isAdmin) $("adminWelcome").textContent = `Mwalowa ngati ${user.email || "admin"}.`;
  if (!isAdmin) show("adminPanel", false);
  if (user) show("loginPanel", false);
}
async function loadStories() {
  if (!supabase) { status("loginMessage", "Choyamba muyenera kulumikiza Supabase mu config.js ndi kukhazikitsa database. Tsatirani README.md."); renderStories(); return; }
  const { data, error } = await supabase.from("stories").select("id,title,category,image_url,body,created_at").order("created_at", {ascending:false});
  if (error) { status("formMessage", "Talephera kutenga nkhani. Yang'anani database policies ndi setup."); console.error(error); return; }
  stories = data || []; renderStories();
}
function renderStories() {
  const q = $("searchInput").value.trim().toLocaleLowerCase();
  const found = stories.filter(s => `${s.title} ${s.category} ${s.body}`.toLocaleLowerCase().includes(q));
  $("stories").innerHTML = found.map(s => {
    const img = imageUrl(s.image_url);
    return `<article class="story-card">${img ? `<div class="story-cover"><img src="${esc(img)}" alt="" loading="lazy"></div>` : `<div class="story-cover">❝</div>`}<div class="story-content"><p class="category">${esc(s.category)}</p><h3>${esc(s.title)}</h3><p>${esc(s.body.replace(/\s+/g," ").slice(0,155))}${s.body.length>155?"…":""}</p><button class="read-more" data-read="${esc(s.id)}" type="button">WERENGANI NKHANI →</button>${currentUser?.id===cfg.adminUserId?`<button class="delete-story" data-delete="${esc(s.id)}" type="button">Chotsani nkhani</button>`:""}</div></article>`;
  }).join("");
  show("emptyState", found.length===0); show("stories", found.length>0);
}
async function openReader(id) {
  const s = stories.find(x => String(x.id)===String(id)); if (!s) return;
  activeStoryId = s.id; $("readerCategory").textContent=s.category; $("readerTitle").textContent=s.title; $("readerBody").textContent=s.body;
  $("commentForm").reset(); status("commentMessage",""); await loadComments();
  $("readerDialog").showModal();
}
async function loadComments() {
  $("commentList").innerHTML = '<p class="muted">Ikutsegula ma comment...</p>';
  const {data,error}=await supabase.from("comments").select("id,name,body,created_at").eq("story_id",activeStoryId).order("created_at",{ascending:false}).limit(100);
  if(error){$("commentList").innerHTML='<p class="muted">Ma comment sanathe kutsegulidwa. Yesani kachiwiri.</p>';console.error(error);return;}
  $("commentList").innerHTML = data.length ? data.map(c=>`<article class="comment"><div class="comment-meta"><strong>${esc(c.name)}</strong><span>${esc(new Date(c.created_at).toLocaleString("ny-MW"))}</span></div><p>${esc(c.body)}</p></article>`).join("") : '<p class="no-comments">Palibe comment panobe. Khalani woyamba kupereka maganizo anu. 😊</p>';
}
$("searchInput").addEventListener("input",renderStories);
$("stories").addEventListener("click",async e=>{
  const read=e.target.closest("[data-read]"); if(read) await openReader(read.dataset.read);
  const del=e.target.closest("[data-delete]"); if(del && currentUser?.id===cfg.adminUserId && confirm("Mukutsimikiza kuti muchotse nkhaniyi?")) {
    const {error}=await supabase.from("stories").delete().eq("id",del.dataset.delete);
    if(error) alert("Kuchotsa nkhani kwalephera. Yang'anani admin policies."); else await loadStories();
  }
});
$("loginToggle").addEventListener("click",()=>show("loginPanel"));
$("closeLogin").addEventListener("click",()=>show("loginPanel",false));
$("adminToggle").addEventListener("click",()=>show("adminPanel"));
$("closeAdmin").addEventListener("click",()=>show("adminPanel",false));
$("cancelStory").addEventListener("click",()=>show("adminPanel",false));
$("loginForm").addEventListener("submit",async e=>{
  e.preventDefault(); if(!supabase){status("loginMessage","Choyamba malizitsani Supabase setup monga momwe README.md ikunenera.");return;}
  const {data,error}=await supabase.auth.signInWithPassword({email:$("adminEmail").value.trim(),password:$("adminPassword").value});
  if(error){status("loginMessage","Kulowa kwalephera. Yang'anani email/password ndi Supabase setup.");return;}
  setupState(data.user); status("loginMessage","Mwalowa bwino."); await loadStories();
});
$("logoutButton").addEventListener("click",async()=>{if(supabase) await supabase.auth.signOut();setupState(null);});
$("storyForm").addEventListener("submit",async e=>{
  e.preventDefault();
  if(!supabase || currentUser?.id!==cfg.adminUserId){status("formMessage","Muyenera kulowa ngati admin wovomerezeka.");return;}
  const record={title:$("storyTitle").value.trim(),category:$("storyCategory").value,image_url:imageUrl($("storyImage").value.trim())||null,body:$("storyBody").value.trim(),author_id:currentUser.id};
  const {error}=await supabase.from("stories").insert(record);
  if(error){status("formMessage","Nkhani sinasindikizidwe. Yang'anani RLS policy ndi admin UUID.");console.error(error);return;}
  $("storyForm").reset();status("formMessage","Nkhani yasindikizidwa! Owerenga onse azitha kuiona.");show("adminPanel",false);await loadStories();
});
$("commentForm").addEventListener("submit",async e=>{
  e.preventDefault(); if(!supabase){status("commentMessage","Comments sizinatsegulidwebe: database sinakonzedwe.");return;}
  const name=$("commentName").value.trim(), body=$("commentText").value.trim();
  if(!name||!body)return;
  const {error}=await supabase.from("comments").insert({story_id:activeStoryId,name,body});
  if(error){status("commentMessage","Comment sinatumizidwe. Yesani kachiwiri.");console.error(error);return;}
  $("commentForm").reset();status("commentMessage","Zikomo! Comment yanu yaikidwa.");await loadComments();
});
$("closeReader").addEventListener("click",()=>$("readerDialog").close());
$("readerCloseBottom").addEventListener("click",()=>$("readerDialog").close());
$("readerDialog").addEventListener("click",e=>{if(e.target===$("readerDialog"))$("readerDialog").close();});
$("year").textContent=new Date().getFullYear();
(async()=>{
  if(!supabase){status("loginMessage","Setup sinamalizidwe. Tsegulani README.md kuti mulumikize database ya pa intaneti.");renderStories();return;}
  const {data}=await supabase.auth.getSession();setupState(data.session?.user||null);
  supabase.auth.onAuthStateChange((_event,session)=>setupState(session?.user||null));
  await loadStories();
})();