# Saona Stories — live database version

This version is designed so **only the owner/admin can publish and delete stories**, while visitors can read stories and post comments.

## Important: it is not live until configured
You must create your own Supabase project and add its public project URL/key and admin UUID in `config.js`. Never place a Supabase `service_role` or secret key in browser files.

## Setup checklist
1. Open https://supabase.com/ and create a project.
2. In **Authentication → Users**, create the admin account using your email and a strong password. Keep this account private.
3. Copy the admin user's UUID from the Users list.
4. Open `schema.sql`, replace BOTH instances of `ADMIN_UUID_HERE` with the real UUID, then run the SQL in Supabase **SQL Editor**.
5. In Supabase Project Settings / API, copy the Project URL and publishable (or anon) key.
6. Put those values and the admin UUID in `config.js`.
7. Upload `index.html`, `styles.css`, `app.js`, `config.js`, and `schema.sql` to a static hosting provider. For a simple free demo, GitHub Pages can host the static files; follow https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site
8. After deploying, test: visitors can read and comment; only the admin account can publish/delete stories.

## Secure admin setup
- Do not enable public sign-ups if your Supabase project settings allow disabling them. Create only the admin user yourself.
- The database row-level security policies are the real permission check. Hiding the Add Story button alone is not security.
- The admin UUID must match the authenticated admin account UUID exactly.
- Public comments are open to spam. Before promoting the site widely, consider adding CAPTCHA/rate limiting and a moderation workflow.
- Do not share your admin password or secret keys in chat. If you need help configuring this, share only non-secret error messages; never share passwords or service-role keys.

## Files
- `index.html` — site layout
- `styles.css` — responsive design
- `app.js` — login, story publishing, public comments
- `config.js` — project configuration placeholders
- `schema.sql` — database tables and row-level security policies
