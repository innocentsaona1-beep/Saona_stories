// Lembani Project URL ndi anon/publishable key kuchokera ku Supabase Dashboard.
// Key ya anon/publishable ingakhale mu browser kokha ngati RLS policies zili zolondola.
// MUSAYIKE service_role/secret key pano.
window.SAONA_CONFIG = {
  supabaseUrl: "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE",
  supabaseAnonKey: "PASTE_YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY_HERE",
  adminUserId: "PASTE_ADMIN_USER_UUID_HERE"
};